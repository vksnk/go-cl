nvcc -cubin kernel.cu
javac -cp ".:lib/jcuda.jar" CudaRndVectorsMul.java
