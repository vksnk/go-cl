import java.io.*;

import jcuda.*;
import jcuda.driver.*;

public class CudaRndVectorsMul {
	public static void main(String args[]) {
		CudaRndVectorsMul app = new CudaRndVectorsMul();
		
		if(args.length > 0) {
			if(args[0].equals("--serial")) app.isRandom = false;
		}
		
		if(app.isRandom) app.fillRandom(1234); else app.fillAndCopySerial();

		app.mulVectors();
		app.getBackData();
		app.checkResult();
		app.free();
	}
	
	public CudaRndVectorsMul() { init();}
	
	public void init() {
		bufferSize = BUFFER_SIZE * Sizeof.INT;

		JCudaDriver.setExceptionsEnabled(true);
		JCudaDriver.cuInit(0);

		JCudaDriver.cuDeviceGet(dev, 0);
		JCudaDriver.cuCtxCreate(pctx, 0, dev);

		CUmodule module = new CUmodule();
		JCudaDriver.cuModuleLoad(module, KERNEL_FILE_NAME);

		JCudaDriver.cuModuleGetFunction(setupRngFn, module, SETUP_RNG_KERNEL);
		JCudaDriver.cuModuleGetFunction(generateRngFn, module, GENERATE_RNG_KERNEL);
		JCudaDriver.cuModuleGetFunction(mulVectorsFn, module, MUL_VECTORS_KERNEL);

		System.out.println("Allocating buffers");
		
		JCudaDriver.cuMemAlloc(buffer1, bufferSize);
		JCudaDriver.cuMemAlloc(buffer2, bufferSize);
		JCudaDriver.cuMemAlloc(output, bufferSize);
	}
	
	public void fillRandom(int seed) {
		System.out.println("Filling random");
		CUdeviceptr rndState = new CUdeviceptr();
		JCudaDriver.cuMemAlloc(rndState, THREADS_PER_BLOCK * CURAND_STATE_SIZEOF);
		fillDevRandom(rndState, buffer1);
		fillDevRandom(rndState, buffer2);
		JCudaDriver.cuMemFree(rndState);
	}

	protected void initDevRandom(CUdeviceptr rndState, int seed) {
		int offset = 0;
		
		offset = JCudaDriver.align(offset, Sizeof.POINTER);
		JCudaDriver.cuParamSetv(setupRngFn, offset, Pointer.to(rndState), Sizeof.POINTER);
		offset += Sizeof.POINTER;

		offset = JCudaDriver.align(offset, Sizeof.INT);
		JCudaDriver.cuParamSetv(setupRngFn, offset, Pointer.to(new int[]{seed}), Sizeof.INT);
		offset += Sizeof.INT;
		
		JCudaDriver.cuParamSetSize(setupRngFn, offset);
		JCudaDriver.cuFuncSetBlockShape(setupRngFn, THREADS_PER_BLOCK, 1, 1);

		JCudaDriver.cuLaunch(setupRngFn);
		JCudaDriver.cuCtxSynchronize();
	}

	protected void fillDevRandom(CUdeviceptr rndState, CUdeviceptr buffer) {
		int offset = 0;
		
		offset = JCudaDriver.align(offset, Sizeof.POINTER);
		JCudaDriver.cuParamSetv(generateRngFn, offset, Pointer.to(rndState), Sizeof.POINTER);
		offset += Sizeof.POINTER;
		
		offset = JCudaDriver.align(offset, Sizeof.POINTER);
		JCudaDriver.cuParamSetv(generateRngFn, offset, Pointer.to(buffer), Sizeof.POINTER);
		offset += Sizeof.POINTER;

		offset = JCudaDriver.align(offset, Sizeof.INT);
		JCudaDriver.cuParamSetv(generateRngFn, offset, Pointer.to(new int[]{BUFFER_SIZE}), Sizeof.INT);
		offset += Sizeof.INT;

		offset = JCudaDriver.align(offset, Sizeof.INT);
		JCudaDriver.cuParamSetv(generateRngFn, offset, Pointer.to(new int[]{MODULO}), Sizeof.INT);
		offset += Sizeof.INT;


		JCudaDriver.cuParamSetSize(generateRngFn, offset);

		JCudaDriver.cuFuncSetBlockShape(generateRngFn, THREADS_PER_BLOCK, 1, 1);

		JCudaDriver.cuLaunch(generateRngFn);
		JCudaDriver.cuCtxSynchronize();
	}
	
	public void fillAndCopySerial() {
		for(int i = 0; i < BUFFER_SIZE; i++) {
			hostBuffer1[i] = i % MODULO;
			hostBuffer2[i] = i % MODULO;
		}

		JCudaDriver.cuMemcpyHtoD(buffer1, Pointer.to(hostBuffer1), bufferSize);
		JCudaDriver.cuMemcpyHtoD(buffer2, Pointer.to(hostBuffer2), bufferSize);
	}
	
	public void mulVectors() {
		int offset = 0;

		offset = JCudaDriver.align(offset, Sizeof.POINTER);
		JCudaDriver.cuParamSetv(mulVectorsFn, offset, Pointer.to(buffer1), Sizeof.POINTER);
		offset += Sizeof.POINTER;

		offset = JCudaDriver.align(offset, Sizeof.POINTER);
		JCudaDriver.cuParamSetv(mulVectorsFn, offset, Pointer.to(buffer2), Sizeof.POINTER);
		offset += Sizeof.POINTER;

		offset = JCudaDriver.align(offset, Sizeof.POINTER);
		JCudaDriver.cuParamSetv(mulVectorsFn, offset, Pointer.to(output), Sizeof.POINTER);
		offset += Sizeof.POINTER;

		offset = JCudaDriver.align(offset, Sizeof.INT);
		JCudaDriver.cuParamSetv(mulVectorsFn, offset, Pointer.to(new int[]{BUFFER_SIZE}), Sizeof.INT);
		offset += Sizeof.INT;

		JCudaDriver.cuParamSetSize(mulVectorsFn, offset);

		JCudaDriver.cuFuncSetBlockShape(mulVectorsFn, THREADS_PER_BLOCK, 1, 1);

		int blockNum = ((BUFFER_SIZE + THREADS_PER_BLOCK - 1) / THREADS_PER_BLOCK);
		JCudaDriver.cuLaunchGrid(mulVectorsFn, blockNum, 1);
		JCudaDriver.cuCtxSynchronize();
	}
	
	public void getBackData() {
		//get back input buffers if need
		if(isRandom) {
			JCudaDriver.cuMemcpyDtoH(Pointer.to(hostBuffer1), buffer1, bufferSize);
			JCudaDriver.cuMemcpyDtoH(Pointer.to(hostBuffer2), buffer2, bufferSize);
		}

		JCudaDriver.cuMemcpyDtoH(Pointer.to(hostOutput), output, bufferSize);
	}
	
	//check for correctness
	public void checkResult() {
		boolean correct = true;
		for(int i = 0; i < BUFFER_SIZE; i++) {
			correct = correct && (hostBuffer1[i] * hostBuffer2[i] == hostOutput[i]);
			//System.out.printf("%d %d %d\n", hostBuffer1[i], hostBuffer2[i], hostOutput[i]);
			//if(i == 512) break;
		}

		if(correct) {
			System.out.println("Output is correct");
		} else {
			System.out.println("Output is not correct");			
		}	
	}
	
	public void free() {
		System.out.println("Releasing buffers");

		JCudaDriver.cuMemFree(buffer1);
		JCudaDriver.cuMemFree(buffer2);
		JCudaDriver.cuMemFree(output);
	}

	public boolean isRandom = true;
	public int bufferSize;

	public CUcontext pctx = new CUcontext();
	public CUdevice dev = new CUdevice();

	public CUdeviceptr buffer1 = new CUdeviceptr();
	public CUdeviceptr buffer2 = new CUdeviceptr();
	public CUdeviceptr output = new CUdeviceptr();

	public CUfunction setupRngFn = new CUfunction();
	public CUfunction generateRngFn = new CUfunction();
	public CUfunction mulVectorsFn = new CUfunction();

	public int hostBuffer1[] = new int[BUFFER_SIZE];
	public int hostBuffer2[] = new int[BUFFER_SIZE];
	public int hostOutput[] = new int[BUFFER_SIZE];

	//filename of cubin file
	public static String KERNEL_FILE_NAME = "kernel.cubin";
	//kernel functions names
	public static String SETUP_RNG_KERNEL = "setupRng";
	public static String GENERATE_RNG_KERNEL = "generateRng";
	public static String MUL_VECTORS_KERNEL = "mulVectors";
	//
	public static int CURAND_STATE_SIZEOF = 40;
	public static int THREADS_PER_BLOCK = 256;
	//different constants
	public static int BUFFER_SIZE = 100000;
	public static int MODULO = 10000;

}
