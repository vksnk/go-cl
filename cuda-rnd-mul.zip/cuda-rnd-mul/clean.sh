rm *.class
rm *.cubin
