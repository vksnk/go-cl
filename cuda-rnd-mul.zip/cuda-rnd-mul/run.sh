java -cp ".:lib/jcuda.jar"  -Djava.library.path="lib/" CudaRndVectorsMul
